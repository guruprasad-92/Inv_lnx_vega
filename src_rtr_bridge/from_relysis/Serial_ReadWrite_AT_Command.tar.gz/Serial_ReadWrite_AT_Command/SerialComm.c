#include <stdio.h>
#include <string.h>
#include <fcntl.h> 
#include <errno.h> 
#include <termios.h>
#include <unistd.h> 

int main()
{
	int ttyFD = 0;
    struct termios tty;
    unsigned char SampleCmd[] = {'A', 'T', '\r', '\0'};
    int i_WriteBytes = 0;
    
    memset (&tty, 0, sizeof tty);
    
    ttyFD = open("/dev/ttyAT", O_RDWR| O_NONBLOCK | O_NDELAY );
    if(ttyFD < 0)
    {
        printf("Error in opening /dev/ttyAT\n");
        return 1;
    }
    else
    {
		printf("AT port opened successfully\n");
	}
    
    if (tcgetattr ( ttyFD, &tty ) != 0 )
    {
        printf("Error from tcgetattr\n");
        return 1;
    }
    
    cfsetospeed (&tty, B57600);
    cfsetispeed (&tty, B57600);
    
    tty.c_cflag     &=  ~PARENB;                            /* parity */
    tty.c_cflag     &=  ~CSTOPB;                            /* stop bits */
    //tty.c_cflag   &=  ~CSIZE;                             /* */
    tty.c_cflag     |=  CS8;                                /* data bits */
    tty.c_cflag     &=  ~CRTSCTS;                           /* no hardware flow control */
    tty.c_iflag     &=  ~(IXON | IXOFF | IXANY);            /* no s/w flow ctrl */
    tty.c_lflag     =   0;                                  /* non canonical */
    tty.c_oflag     =   0;                                  /* no remapping, no delays */
    tty.c_cc[VMIN]  =   0;                                  /* read doesn't block */
    tty.c_cc[VTIME] =   0;                                  /* read timeout */
    tty.c_cflag     |=  CREAD | CLOCAL;                     /* turn on READ & ignore ctrl lines */
    tty.c_lflag     &=  ~(ICANON | ECHO | ECHOE | ISIG);    /* */
    //tty.c_oflag     &=  ~OPOST;                           /* */
    
    tcflush( ttyFD, TCIFLUSH );
    if ( tcsetattr ( ttyFD, TCSANOW, &tty ) != 0)
    {
        printf("Error from tcsetattr\n");
        return 1;
    }
    
    i_WriteBytes = write(ttyFD, SampleCmd, sizeof(SampleCmd) -1 );
    printf("written bytes = %d\n", i_WriteBytes);
    if (i_WriteBytes < 0)
    {
        printf("failed to write value on port\n");
        return 1;
    }
    sleep(1);
    
    char read_buf [256];
    memset(&read_buf, '\0', sizeof(read_buf));
    int num_bytes = read(ttyFD, &read_buf, sizeof(read_buf));

	if (num_bytes < 0) {
	    printf("Error reading: %s", strerror(errno));
	}
	printf("Read %i bytes.\n Received message: %s", num_bytes, read_buf);

    close(ttyFD);
    return 0;
}
